export const addTask = (taskText) => ({
    type: 'ADD_TASK',
    payload: {
      id: new Date().getTime(),
      text: taskText,
      completed: false,
    },
  });
  
  export const deleteTask = (taskId) => ({
    type: 'DELETE_TASK',
    payload: {
      id: taskId,
    },
  });
  
  export const toggleTask = (taskId) => ({
    type: 'TOGGLE_TASK',
    payload: {
      id: taskId,
    },
  });
  